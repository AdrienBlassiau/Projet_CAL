# URM en OCaml 🚀

Ceci est le manuel d'utilisation du petit projet de construction de quelques outils de manipulation d'URM.

## 💾 Utilisation

### Système Linux

Le projet est construit de manière à compiler avec **une version d'OCaml >= à la version 4.02**. Il a été testé sur les machines de l'école via ssh.

Le projet comporte 5 fichiers dont celui ci.

**Pour lancer les tests unitaires, rentrer la commande suivante à la racine du projet :**

```bash
make clean && make all && ./run
```

**Pour nettoyer le dossier :**

```bash
make clean
```

### Rapport et Sujet

Le rapport du projet ainsi que le sujet se trouvent dans le dossier doc.